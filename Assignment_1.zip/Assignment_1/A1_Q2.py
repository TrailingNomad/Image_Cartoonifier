import numpy as np
l=[[1,2,3,4],[5,6,7,8],[9,10,11,12],[13,14,15,16]]
print("Original list : \n",l)
a=np.array(l)
print("4 X 4 Array : \n",a)
print("Diagonal elements : ",np.diag(a)," \nTrace : ",np.trace(a))
for i in range(0,4):
    print(f"Minimum element in row {i} : {a[:][i].min()}")
    print(f"Maximum element in row {i} : {a[:][i].max()}")
b=np.random.uniform(low=0,high=1,size=(4,4))
print("Random 4 X 4 Array : \n",b)
c=np.matmul(a,b)
print("A X B :\n",c)