import pandas as pd
import numpy as np
a=np.zeros(12)
c=np.zeros(12)
df=pd.read_csv('Data - STOCK_US_XNYS_CSV.csv')
df['Month']=pd.to_datetime(df['Date']).dt.month
for index,row in df.iterrows():
    a[row['Month']-1]=a[row['Month']-1]+row['Close']
    c[row['Month']-1]=c[row['Month']-1]+1
for i in range(0,12):
    if(c[i]!=0):
        print(f"Average closing value for Month {i+1} is {a[i]/c[i]}")
    else:
        print(f"No sales for Month {i+1}")