import numpy as np
class Array():
    def __init__(self, array):
        self.array = array
    def get_array(self):
        l=int(input("Enter the length of the array : "))
        self.array=np.zeros(l)
        print("Enter the elements of the array : ")
        for i in range(0,l):
            self.array[i]=float(input())
        for j in range(1,l):
            k=self.array[j]
            i=j-1
            while i>=0 and self.array[i]>k :
                self.array[i+1]=self.array[i]
                i=i-1
            self.array[i+1]=k       
        return self.array        
a=Array(array=[])
print(f"Corresponding sorted array : {a.get_array()}")