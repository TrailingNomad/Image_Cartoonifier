import numpy as np
import pandas as pd
def compute_cost(y,h):
    J=-(np.matmul(y.T,np.log(h))+np.matmul((1-y).T,np.log(1-h)))/len(y)
    return J
def compute_gradient(h,x,y):
    grad=np.matmul(x,h-y)/len(y)
    return grad
def gradient_descent(n,alpha,x,y,t):
    i=0
    while(i<n):
        h=1/(1+np.e**-(np.matmul(t.T,x)))
        t=t-alpha*compute_gradient(h,x,y)
        i=i+1
    return t
def predict(n,alpha,x,y,t_init,test):
    t=gradient_descent(n,alpha,x,y,t_init)
    return (1/(1+np.e**-np.matmul(t.T,test)))
df=pd.read_csv('corrected train set.csv')
df=df.dropna()
df1=pd.read_csv('week 1 test.csv')
x1=np.array(df['loading'])
x2=np.ones(len(x1))
x=np.block([[x2],[x1]])
y=np.array(df['failure']).T
t_init=np.array([2,3]).T
test1=np.array(df1['loading']).T
test2=np.ones(len(test1))
test=np.block([[test2],[test1]])
alpha=0.01
n=10000
print(predict(n,alpha,x,y,t_init,test))
