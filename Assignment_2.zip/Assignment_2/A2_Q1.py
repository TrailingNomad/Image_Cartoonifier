import numpy as np
import matplotlib.pyplot as plt
def compute_cost(w,b,exp,sal):
    h=w*exp+b
    J=np.sum((h-sal)**2/(2*len(exp)))
    return J
def compute_gradient(h,sal,exp):
    delb=np.sum(h-sal)/len(exp)
    delw=np.matmul((h-sal).T,exp)/len(exp)
    return delw,delb
exp=np.array([1,3,5]).T
sal=np.array([300,480,570]).T
plt.scatter(exp,sal)
plt.xticks(exp)
plt.title('Plot')
plt.xlabel('Number of years of experience')
plt.ylabel('Salary')
plt.show()
w=200
b=100
h=w*exp+b
J=compute_cost(w,b,exp,sal)
print(f"Total cost : {J}")
delw,delb=compute_gradient(h,sal,exp)
print(f"delw : {delw}")
print(f"delb : {delb}")
