import numpy as np
import matplotlib.pyplot as plt
def compute_cost(w,b,exp,sal):
    h=w*exp+b
    J=np.sum((h-sal)**2/(2*len(exp)))
    return J
def compute_gradient(h,sal,exp):
    delb=np.sum(h-sal)/len(exp)
    delw=np.matmul((h-sal).T,exp)/len(exp)
    return delw,delb
def gradient_descent(exp,sal,w_init,b_init,n,alpha):
    i=0
    J1=np.zeros(n).T
    n1=np.zeros(n).T
    while(i<n):
        h=w_init*exp+b_init
        delw,delb=compute_gradient(h,sal,exp)
        w_init=w_init-alpha*delw
        b_init=b_init-alpha*delb
        J1[i]=compute_cost(w_init,b_init,exp,sal)
        n1[i]=i
        if(J1[i]<10**-6):
            break
        i=i+1
    return w_init,b_init,J1,n1

exp=np.array([1,3,5]).T
sal=np.array([300,480,570]).T
plt.scatter(exp,sal)
plt.title('Plot')
plt.xlabel('Number of years of experience')
plt.ylabel('Salary')


n=10000
alpha=0.01
w_init=0
b_init=0

w_final,b_final,J1,n1=gradient_descent(exp,sal,w_init,b_init,n,alpha)
x=np.linspace(0,9,10)
y=w_final*x+b_final
print(f"Equation of Linear regression line : y = {w_final} x + {b_final}")
plt.plot(x,y,label='Linear regression line')
plt.legend()
plt.show()
plt.plot(n1,J1)
plt.xlabel('Number of iterations')
plt.ylabel('Cost function')
plt.title('J Vs N')
plt.show()